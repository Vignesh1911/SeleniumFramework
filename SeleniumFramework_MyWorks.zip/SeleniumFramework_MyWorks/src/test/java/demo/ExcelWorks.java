package demo;

import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelWorks {
	static String projectpath;
	static XSSFWorkbook wb;
	static XSSFSheet sheet;
	
	public ExcelWorks(String excelpath, int sheetnum) throws InvalidFormatException, IOException {
		
		wb = new XSSFWorkbook(excelpath);
		sheet = wb.getSheetAt(sheetnum);
	}

	public static int RowCount() throws InvalidFormatException, IOException {
		int rowNum = sheet.getPhysicalNumberOfRows();
		System.out.println("Total Number of Rows in the excel is : "+rowNum);
		return rowNum;
	}
	
	public static int ColCount() throws InvalidFormatException, IOException {
		int colNum = sheet.getRow(0).getPhysicalNumberOfCells();
		System.out.println("Total Number of Columns in the excel is : "+colNum);
		return colNum;
	}

	public static String CellDataString(int rowNum, int colNum) throws InvalidFormatException, IOException {
		String cellValue = sheet.getRow(rowNum).getCell(colNum).getStringCellValue();
//		System.out.println(cellValue);
		return cellValue;
	}

	public static void CellDataNum(int rowNum, int colNum) throws InvalidFormatException, IOException {
		double cellValue = sheet.getRow(rowNum).getCell(colNum).getNumericCellValue();
		System.out.println(cellValue);
	}

	
}