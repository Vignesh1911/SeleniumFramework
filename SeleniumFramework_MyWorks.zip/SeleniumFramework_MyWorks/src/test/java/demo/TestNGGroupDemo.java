package demo;

import org.testng.annotations.Test;

//@Test(groups = {"AllClassTest"})
public class TestNGGroupDemo {
	
	@Test(groups = {"Functional"})
	public void test1() {
		System.out.println("Test 1 is executed");
	}
	@Test
	public void test2() {
		System.out.println("Test 2 is executed");
	}
	@Test(groups = {"Functional", "System"})
	public void test3() {
		System.out.println("Test 3 is executed");
	}
	@Test(groups = {"Functional", "System", "Integration"})
	public void test4() {
		System.out.println("Test 4 is executed");
	}
	@Test(groups = {"Functional", "Regression"})
	public void test5() {
		System.out.println("Test 5 is executed");
	}
	@Test(groups = {"Regression", "System"})
	public void test6() {
		System.out.println("Test 6 is executed");
	}
	@Test(groups = {"Regression"})
	public void test7() {
		System.out.println("Test 7 is executed");
	}
	
}
