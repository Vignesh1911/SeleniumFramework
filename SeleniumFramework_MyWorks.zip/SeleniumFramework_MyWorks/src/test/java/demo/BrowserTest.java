package demo;

import org.openqa.selenium.By;

//import java.awt.Dimension;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserTest {

	public static void main(String[] args){
		
		String driverpath = System.getProperty("user.dir");
		System.out.println(driverpath);

		System.setProperty("webdriver.chrome.driver" , driverpath+"/drivers/chromedriver.exe");
		
		WebDriver obj = new ChromeDriver();
		obj.manage().window().maximize();
		
		obj.get("https://google.com");
		
		obj.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
		try {
		    obj.findElement(By.name("btnK")).click();
}
		catch(Exception exp) {
			System.out.println("Exception Handled");
			System.out.println("Message is : "+exp.getMessage());
			System.out.println("Cause is : "+exp.getCause());
			exp.printStackTrace();
		}
	
        obj.close();
        obj.quit();
		
	}

}
