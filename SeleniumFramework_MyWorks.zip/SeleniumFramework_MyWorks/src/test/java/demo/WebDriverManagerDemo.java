package demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class WebDriverManagerDemo {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
//		WebDriverManager.chromedriver().version("2.36").setup(); -- To select on which version of driver should the program run.
		WebDriver obj = new ChromeDriver();
		obj.get("https://google.com");
		obj.manage().window().fullscreen();
		Thread.sleep(2000);
		System.out.println("done");
        obj.close();
        obj.quit();
		
	}
	
}
