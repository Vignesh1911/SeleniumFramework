package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DesiredCapabilitiesDemo {

	public static void main(String[] args) {
		WebDriverManager.chromedriver().setup();
		
		DesiredCapabilities descaps = new DesiredCapabilities();
		descaps.setBrowserName("My Chrome");
		System.out.println(descaps);

		
		WebDriver obj = new ChromeDriver();
		obj.manage().window().maximize();
		obj.get("https://google.com");
		obj.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
		obj.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
		obj.close();

	}

}
