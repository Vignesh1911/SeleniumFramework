package demo;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExcelDataProvider {
	static WebDriver driver;
	
	@BeforeTest
	public void setUpTest() {
		WebDriverManager.chromedriver().setup(); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@Test(dataProvider = "test1Data")
	public void mainTest(String Username, String Password) throws InterruptedException {
		System.out.println(Username+" | "+Password);
		
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		driver.findElement(By.id("txtUsername")).sendKeys(Username);
		driver.findElement(By.id("txtPassword")).sendKeys(Password);
//		driver.findElement(By.id("btnLogin")).click();
		Thread.sleep(3000);
		driver.close();
		driver.quit();
	}
	
	
	@DataProvider(name = "test1Data")
	public Object [][] getData() throws InvalidFormatException, IOException  {
		String projectpath = System.getProperty("user.dir");
		Object data[][] = dataProvider(projectpath+"/excel/sample.xlsx", 0);
		return data;
	}
	
	public Object[][] dataProvider(String excelpath, int sheetnum) throws InvalidFormatException, IOException {
		
		ExcelWorks obj1 = new ExcelWorks(excelpath, sheetnum);
		int rowCount = obj1.RowCount();
		int colCount = obj1.ColCount();
		
		Object data[][] = new Object[rowCount-1][colCount];
		
		for(int i=1 ; i<rowCount ; i++) {
			for(int j=0 ; j<colCount ; j++) {
				
				String cellData = obj1.CellDataString(i, j);
//				System.out.print(cellData+ " | ");
				data[i-1][j] = cellData;
			}
//			System.out.println();
		}
		return data;
		
	}

}
