package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class HeadlessBrowserDemo {
	
public static void headLessTest() throws InterruptedException {
	WebDriverManager.chromedriver().setup();
	
	ChromeOptions obj1 = new ChromeOptions();
	obj1.addArguments("--headless");
	
	WebDriver obj = new ChromeDriver(obj1);
	
	
	obj.get("https://google.com");
	obj.manage().window().maximize();
	obj.findElement(By.xpath("//input[@name='q']")).sendKeys("Murugesan Thiruselvi");
    obj.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
    Thread.sleep(7000);
    System.out.println(obj.getTitle());
	obj.close();
	obj.quit();
	System.out.println("Headless Browser is Working");
}
	
	public static void main(String[] args) throws InterruptedException {
		headLessTest();	
	}
}
