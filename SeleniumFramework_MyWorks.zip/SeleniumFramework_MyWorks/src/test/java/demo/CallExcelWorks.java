package demo;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

public class CallExcelWorks {

	public static void main(String[] args) throws InvalidFormatException, IOException {
		
		String projectpath = System.getProperty("user.dir");
		
		ExcelWorks obj = new ExcelWorks(projectpath+"/excel/sample.xlsx", 0);
		
		obj.RowCount();
		obj.ColCount();
		obj.CellDataNum(6, 1);
		obj.CellDataString(0, 0);

	}

}
