package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class FindWebElements {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver obj = new ChromeDriver();
		obj.get("https://google.com");
		Thread.sleep(4000);
		obj.manage().window().fullscreen();
		
		obj.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
	    obj.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
		obj.close();
	}
	
}
