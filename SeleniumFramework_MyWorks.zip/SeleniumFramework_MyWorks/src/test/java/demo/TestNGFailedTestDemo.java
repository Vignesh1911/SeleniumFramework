package demo;

import org.junit.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

public class TestNGFailedTestDemo {
	
	@Test
	public void test1() {
		System.out.println("Test 1 is executed");
	}
	@Test
	public void test2() {
		System.out.println("Test 2 is executed");
//		int i=1/0;
	}
	@Test(retryAnalyzer = listeners.TestNGRetryAnalyzerDemo.class)
	public void test3() {
		System.out.println("Test 3 is executed");
		Assert.assertTrue(0>1);
	}
	@Test
	public void test4() {
		System.out.println("Test 4 is executed");
	}

}
