package demo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

public class Log4jDemo {
 
	 static org.apache.logging.log4j.Logger Logger = LogManager.getLogger(Log4jDemo.class);


	public static void main(String[] args) {

		
		System.out.println("\n Hello World \n");
		Logger.trace("This is a Trace Message");
		Logger.info("This is an information Message");
		Logger.error("This is an error Message");
		Logger.warn("This is a warning Message");
		Logger.fatal("This is a Fatal Message");
		System.out.println("\n Completed");

		
	}

}
