package demo;

import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleSearch {
	
	public static void mymethod() {
	
	WebDriverManager.chromedriver().setup(); /*Webdriver Manager snippet to reduce the line of code*/
	WebDriver obj = new ChromeDriver();
	obj.manage().window().maximize();
	obj.get("https://google.com");
	
	obj.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
//	The below line of code is taken from Katalon recorder.
//	obj.findElement(By.name("btnK")).sendKeys(Keys.RETURN);
    obj.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
	obj.close();
	}

	public static void main(String[] args) {
		
//		GoogleSearch obj2 = new GoogleSearch();
//  Calling the method without an object as the method is defined as Static
		
		mymethod();
		System.out.println("Execution Completed");
	}
	
}
