package demo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;


public class ImpExpWaitsDemo {

	public static void main(String[] args) {


		WebDriverManager.chromedriver().setup();
		WebDriver obj = new ChromeDriver();
		obj.get("https://google.com");
		
		obj.manage().window().maximize();
//		obj.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebDriverWait wait = new WebDriverWait(obj, 10);

		obj.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[@id='tdddf']/div[2]")));

//		obj.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
		obj.close();
	}

}


