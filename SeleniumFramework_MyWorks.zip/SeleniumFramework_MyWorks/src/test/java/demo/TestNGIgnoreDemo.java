package demo;

import org.junit.Assert;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

public class TestNGIgnoreDemo {
	
	@Test
	public void test1() {
		System.out.println("I'm running Test 1");
	}
	@Test
	public void test2() {
		Assert.assertTrue(false);
		System.out.println("I'm running Test 2");
	}
	
}
