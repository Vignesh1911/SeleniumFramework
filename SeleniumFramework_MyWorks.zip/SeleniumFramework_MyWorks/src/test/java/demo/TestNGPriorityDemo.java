package demo;

import org.testng.annotations.Test;

public class TestNGPriorityDemo {

	@Test(priority = 3)
	public void test1() {
		System.out.println("Test 1 Completed");
	}
	@Test(priority = 4)
	public void test2() {
		System.out.println("Test 2 Completed");
	}
	@Test(priority = -3)
	public void test3() {
		System.out.println("Test 3 Completed");
	}
	
}
