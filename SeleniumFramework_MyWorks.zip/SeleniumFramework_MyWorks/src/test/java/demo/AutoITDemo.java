package demo;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AutoITDemo {

	public static void main(String[] args) throws IOException, InterruptedException  {


		WebDriverManager.chromedriver().setup();
		WebDriver obj = new ChromeDriver();
		obj.get("http://www.tinyupload.com/");
		obj.manage().window().maximize();
		Thread.sleep(7000);
		
	
		
		//		obj.findElement(By.xpath("//input[@name='uploaded_file']")).click();
	
		Runtime.getRuntime().exec("D:/FileUploadScript.exe");



//		obj.close();
//		obj.quit();
		System.out.println("Success");


	}

}
