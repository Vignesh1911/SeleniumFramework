package listeners;

import org.junit.Assert;
import org.testng.SkipException;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(listeners.TestNGListeners.class)
public class TestNGListenerDemo2 {
	@Test
	public void test4() {
		System.out.println("Running function test4");
	}
	@Test
	public void test5() {
		System.out.println("Running function test5");
	}
	@Test
	public void test6() {
		System.out.println("Running function test6");
		throw new SkipException("This test is Skipped");
	}
}
