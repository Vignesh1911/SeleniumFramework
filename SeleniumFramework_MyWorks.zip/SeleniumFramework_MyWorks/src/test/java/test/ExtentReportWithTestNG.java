package test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExtentReportWithTestNG {
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	ExtentTest test;

	WebDriver driver;

	@BeforeSuite
	public void SetUpTest() {
		htmlReporter = new ExtentHtmlReporter("extentReportsTestNG.html");
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
	}

	@BeforeTest
	public void TestInitiation() {

		WebDriverManager.chromedriver().setup(); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	@Test
	public void AfterTest() {
		ExtentTest test = extent.createTest("Google Search Test", "Test for Google HomePage Search");
		driver.get("https://google.com");
		test.log(Status.INFO, "Test Case is Starting");
		test.pass("Navigates to Google HomePage");
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
		test.pass("Input is given in SearchBox");
		test.addScreenCaptureFromBase64String("image", "Captured Google Image");
	    driver.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
		test.pass("SearchButton is Clicked");

	}

	@AfterTest
	public void TearDownTest() {
		driver.close();
	    driver.quit();
		System.out.println("Testing Completed");	
	}
	
	@AfterSuite
	public void ProgramEnds() {
		 extent.flush();
	}

}
