package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ExtentReportsDemo {
	
	private static WebDriver driver;

	public static void main(String[] args) {
//   SYNTAX for ExtentHTMLREPORT for Creating Objects and implementing their Class
		ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extentReports.html");
		ExtentReports extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		
// 	TEST is Staring here with ExtentTest(in-built) Class and initiating the driver		
        ExtentTest test = extent.createTest("Google Search Test", "Test for Google HomePage Search");
        WebDriverManager.chromedriver().setup(); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		test.log(Status.INFO, "Test Case is Starting");

		
//	Actual TEST Begins here		
		driver.get("https://google.com");
		test.pass("Navigates to Google HomePage");
		
		driver.findElement(By.xpath("//input[@name='q']")).sendKeys("Java Selenium");
		test.pass("Input is given in SearchBox");
		
		test.addScreenCaptureFromBase64String("image", "Captured Google Image");
		
	    driver.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
	    test.pass("SearchButton is Clicked");
	    
	    driver.close();
	    driver.quit();
	    test.pass("Browser is Closed");
	    test.info("Test is completed Successfully");
	    
	    
	    extent.flush();		
		
	}

}
