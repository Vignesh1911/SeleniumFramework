package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pageobjectmodel.GoogleSearchPageObjects;

public class TestNG_GoogleSearchTest2 {
	
	private static WebDriver driver;

	@BeforeTest
	public void START_searchtest() {
		WebDriverManager.chromedriver().setup(); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://google.com");
	}
	
	@Test
	public static void GoogleSearchTest() {
		GoogleSearchPageObjects searchobj = new GoogleSearchPageObjects(driver);
		searchobj.textbox_search("Working on TestNG Framework");
		searchobj.search_button();
	}
	
	@Test
	public static void GoogleSearchTestNew() {
		driver.get("https://google.com");
		GoogleSearchPageObjects searchobj1 = new GoogleSearchPageObjects(driver);
		searchobj1.textbox_search("Working on Python & Java");
		searchobj1.search_button();
	}
	
	@AfterTest
	public void END_searchtest() {
		driver.close();
		System.out.println("Execution Completed");
	}
}
