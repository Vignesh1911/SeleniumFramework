package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageobjectmodel.GoogleSearchPageObjects;


public class GoogleSearchPagesTest {
	
	private static WebDriver driver;
		
	public static void main(String[] args) {
		GoogleSearchTest();
	}
	 
	public static void GoogleSearchTest() {
	
	WebDriverManager.chromedriver().setup(); 
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	
	GoogleSearchPageObjects searchobj = new GoogleSearchPageObjects(driver);
	
	driver.get("https://google.com");
	searchobj.textbox_search("Java Selenium");
	searchobj.search_button();
	
	driver.close();
	System.out.println("Execution Completed");
	}
}
