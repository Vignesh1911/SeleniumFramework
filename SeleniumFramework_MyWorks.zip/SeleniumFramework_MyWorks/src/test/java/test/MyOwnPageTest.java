package test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;
import pageobjectmodel.MyOwnPageObjects;


public class MyOwnPageTest {
	
	static WebDriver driver;

	public static void main(String[] args) {
		OrangeHrmPageTest();
	}
	
	public static void OrangeHrmPageTest() {
		
		WebDriverManager.chromedriver().setup(); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		MyOwnPageObjects obj = new MyOwnPageObjects(driver);
		driver.get("https://opensource-demo.orangehrmlive.com/");
		
		obj.enter_username("Admin");
		obj.enter_password("admin123");
		obj.clickbutton();
		obj.clickWelcome();
		obj.clickLogout();
		
		driver.close();
		System.out.println("Execution Completed and Logout is Successful");
		
	}

}
