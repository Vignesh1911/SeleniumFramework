package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

import pageobjectmodel.GoogleSearchPage;

public class GoogleSearchTest {
	
	private static WebDriver obj = null;
	
	public static void main(String[] args) {
		mymethod();
		mymethod1();
	}
	
	public static void mymethod() {
	
	WebDriverManager.chromedriver().setup(); 
	obj = new ChromeDriver();
	obj.manage().window().maximize();
	obj.get("https://google.com");
	
	GoogleSearchPage.textbox_search(obj).sendKeys("Java Selenium Automation");
	GoogleSearchPage.button_search(obj).click();
	System.out.println(obj.getTitle());
	}
	
	public static void mymethod1() {
	obj.get("https://google.com");
	GoogleSearchPage.textbox_search(obj).sendKeys("Learning Test Automation");
	GoogleSearchPage.button_search(obj).click();
	System.out.println(obj.getTitle());

	
	obj.close();
	System.out.println("Execution Completed");
	}
}
