package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import pageobjectmodel.GoogleSearchPageObjects;

public class TestNG_GoogleSearchTest {
	
	private static WebDriver driver;

	@BeforeTest
	public void START_searchtest() {
		WebDriverManager.chromedriver().setup(); 
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://google.com");
	}
	
	@Test
	public static void GoogleSearchTest() {
		GoogleSearchPageObjects searchobj = new GoogleSearchPageObjects(driver);
		searchobj.textbox_search("Java Selenium");
		searchobj.search_button();
	}
	
	@AfterTest
	public void END_searchtest() {
		driver.close();
		System.out.println("Execution Completed");
	}
}
