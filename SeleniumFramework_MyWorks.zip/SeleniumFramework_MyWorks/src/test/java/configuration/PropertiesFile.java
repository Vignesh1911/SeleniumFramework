package configuration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class PropertiesFile {
	private static String browser;
	static Properties prop = new Properties();
	static String projectpath = System.getProperty("user.dir");


	public static void main(String[] args) throws IOException {

		getProperties();
		setProperties();
		getProperties();
		getTest();

	}

	public static void getProperties() throws IOException {
		try {
			InputStream input = new FileInputStream(projectpath+"/src/test/java/configuration/config.properties");
			prop.load(input);
			String browser = prop.getProperty("browser");
			System.out.println(browser);
		}
		catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
			e.printStackTrace();
		}
	}
	public static void setProperties() throws IOException {
		try {
			OutputStream output = new FileOutputStream(projectpath+"/src/test/java/configuration/config.properties");
			prop.setProperty("browser", "Google Chrome");
			prop.store(output, null);
		}
		catch (FileNotFoundException e) {
			System.out.println(e.getMessage());
			System.out.println(e.getCause());
			e.printStackTrace();
		}
	}

	public static void getTest() throws IOException {
		WebDriverManager.chromedriver().setup();
		WebDriver obj = new ChromeDriver();
		obj.get("https://google.com");
		obj.manage().window().maximize();
		InputStream input = new FileInputStream(projectpath+"/src/test/java/configuration/config.properties");
		prop.load(input);
		String browser = prop.getProperty("browser");
		System.out.println(browser);
		obj.findElement(By.xpath("//input[@name='q']")).sendKeys(browser);
		obj.findElement(By.xpath("//form[@id='tsf']/div[2]")).click();
		System.out.println(obj.getTitle());
		obj.close();

	}
}


