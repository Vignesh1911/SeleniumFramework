package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyOwnPageObjects {

	WebDriver driver;
	
	By username = By.xpath("//input[@id='txtUsername']");
	By password = By.xpath("//input[@id='txtPassword']");
	By login_button = By.xpath("//input[@id='btnLogin']");
	By welcome = By.xpath("//a[@id='welcome']");
	By logout = By.xpath("//a[contains(text(),'Logout')]");
	
		public MyOwnPageObjects(WebDriver driver) {
			this.driver = driver;
		}
		
		public void enter_username(String name) {
			driver.findElement(username).sendKeys(name);
		}
		
		public void enter_password(String psswrd) {
			driver.findElement(password).sendKeys(psswrd);
		}
		
		public void clickbutton() {
			driver.findElement(login_button).click();
		}
		
		public void clickWelcome() {
			driver.findElement(welcome).click();
		}
		
		public void clickLogout() {
			driver.findElement(logout).click();
		}

		
		
	}


