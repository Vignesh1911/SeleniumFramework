package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleSearchPageObjects {
	
	WebDriver driver;
	
	
	By textbox_search = By.xpath("//input[@name='q']"); /* By is class as is followed by LOCATORS*/
	By search_button = By.xpath("//form[@id='tsf']/div[2]");
	
	public GoogleSearchPageObjects(WebDriver driver) {
		this.driver = driver;
	}

	public void textbox_search(String input) {
		driver.findElement(textbox_search).sendKeys(input);
		}

	public void search_button() {
		driver.findElement(search_button).click();
	}
	
	}


