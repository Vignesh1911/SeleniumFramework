package pageobjectmodel;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class GoogleSearchPage {
	
	private static WebElement element = null;

	public static WebElement textbox_search(WebDriver obj) {
		
		element = obj.findElement(By.xpath("//input[@name='q']"));
		return element;
	}

public static WebElement button_search(WebDriver obj) {
		
    	element = obj.findElement(By.xpath("//form[@id='tsf']/div[2]"));
		return element;
	}
	
	}


